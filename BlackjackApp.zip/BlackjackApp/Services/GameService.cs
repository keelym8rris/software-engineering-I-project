using BlackjackApp.Models;

namespace BlackjackApp.Services;

public class GameService
{
    public const int MinimumBet = 10;
    public const int MaxChatLength = 200;
    public const int MaxChatHistory = 40;
    public const int ChatColorCount = 12;

    private readonly object _sync = new();
    private readonly Dictionary<string, GameState> _games = new();
    private readonly Dictionary<string, Deck> _decks = new();
    // Maps connectionId -> gameId for fast disconnect lookup
    private readonly Dictionary<string, string> _connectionIndex = new();

    public string CreateGame(string hostConnectionId, string hostName, GameMode mode, string? hostAvatar = null)
    {
        if (!Enum.IsDefined(mode)) throw new ArgumentOutOfRangeException(nameof(mode));

        lock (_sync)
        {
            var game = new GameState { HostConnectionId = hostConnectionId, Mode = mode };
            while (_games.ContainsKey(game.GameId))
                game.GameId = Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();

            game.Players.Add(new Player { ConnectionId = hostConnectionId, Name = hostName, Avatar = hostAvatar });
            _games.Add(game.GameId, game);
            try
            {
                _decks.Add(game.GameId, new Deck(deckCount: 6));
            }
            catch
            {
                _games.Remove(game.GameId);
                throw;
            }

            // The lobby connection is intentionally not indexed. It closes when the
            // host navigates into the game; JoinGame registers the new connection.
            return game.GameId;
        }
    }

    public void DeleteGame(string gameId)
    {
        lock (_sync)
        {
            _games.Remove(gameId);
            _decks.Remove(gameId);
            foreach (var connectionId in _connectionIndex
                         .Where(entry => entry.Value == gameId)
                         .Select(entry => entry.Key)
                         .ToList())
                _connectionIndex.Remove(connectionId);
        }
    }

   public bool TryJoinGame(
    string gameId,
    string connectionId,
    string name,
    string? priorConnectionId,
    string? playerAvatar,
    out string error)
{
    lock (_sync)
    {
        error = "";

        if (!_games.TryGetValue(gameId, out var game))
        {
            error = "No lobby found with that code. Check it and try again.";
            return false;
        }

            var returningPlayer = priorConnectionId == null
                ? null
                : game.Players.FirstOrDefault(p => p.ConnectionId == priorConnectionId);
            var returningSpectator = priorConnectionId == null
                ? null
                : game.Spectators.FirstOrDefault(s => s.ConnectionId == priorConnectionId);
            if (returningSpectator != null)
            {
                _connectionIndex.Remove(returningSpectator.ConnectionId);
                if (game.ChatSenderColors.Remove(returningSpectator.ConnectionId, out var existingColor))
                    game.ChatSenderColors[connectionId] = existingColor;
                returningSpectator.ConnectionId = connectionId;
                _connectionIndex[connectionId] = gameId;
                return true;
            }

            if (returningPlayer != null)
            {
                _connectionIndex.Remove(returningPlayer.ConnectionId);
                if (game.ChatSenderColors.Remove(returningPlayer.ConnectionId, out var existingColor))
                    game.ChatSenderColors[connectionId] = existingColor;
                returningPlayer.ConnectionId = connectionId;
                _connectionIndex[connectionId] = gameId;
                if (game.HostConnectionId == priorConnectionId)
                    game.HostConnectionId = connectionId;
                return true;
            }

            if (returningPlayer != null)
                returningPlayer.ConnectionId = connectionId;

            if (!string.IsNullOrWhiteSpace(playerAvatar))
                returningPlayer.Avatar = playerAvatar;

            _connectionIndex[connectionId] = gameId;

            if (game.HostConnectionId == priorConnectionId)
                game.HostConnectionId = connectionId;

            return true;
        }
}

       
    public GameStateDto? GetGameState(string gameId)
    {
        lock (_sync)
        {
            if (!_games.TryGetValue(gameId, out var game)) return null;

            return new GameStateDto
            {
                GameId = game.GameId,
                HostConnectionId = game.HostConnectionId,
                Mode = game.Mode.ToString(),
                Phase = game.Phase.ToString(),
                Message = game.Message,
                CurrentPlayerConnectionId = game.CurrentPlayer?.ConnectionId,
                Dealer = MapPlayer(game.Dealer, game.Phase == GamePhase.Playing),
                Players = game.Players.Select(player => MapPlayer(player)).ToList(),
                Spectators = game.Spectators.Select(s => new SpectatorDto { ConnectionId = s.ConnectionId, Name = s.Name }).ToList(),
                ChatMessages = game.ChatMessages.Select(m => new ChatMessageDto { Sender = m.Sender, Text = m.Text, ColorIndex = m.ColorIndex }).ToList()
            };
        }
    }

    public string? FindGameForConnection(string connectionId)
    {
        lock (_sync)
            return _connectionIndex.TryGetValue(connectionId, out var id) ? id : null;
    }

    public bool RemovePlayer(string gameId, string connectionId)
    {
        lock (_sync)
        {
            if (!_games.TryGetValue(gameId, out var game)) return false;

            var player = game.Players.FirstOrDefault(p => p.ConnectionId == connectionId);
            if (player == null)
            {
                var spectator = game.Spectators.FirstOrDefault(s => s.ConnectionId == connectionId);
                if (spectator == null) return false;
                game.Spectators.Remove(spectator);
                _connectionIndex.Remove(connectionId);
                return true;
            }

            int removedIndex = game.Players.IndexOf(player);
            bool wasCurrentPlayer = game.Phase == GamePhase.Playing &&
                                    game.CurrentPlayer?.ConnectionId == connectionId;
            bool wasHost = game.HostConnectionId == connectionId;

            game.Players.Remove(player);
            _connectionIndex.Remove(connectionId);

            if (game.Players.Count == 0)
            {
                foreach (var spectator in game.Spectators)
                    _connectionIndex.Remove(spectator.ConnectionId);
                _games.Remove(gameId);
                _decks.Remove(gameId);
                return true;
            }

            if (wasHost)
            {
                game.HostConnectionId = game.Players[0].ConnectionId;
                if (game.Phase == GamePhase.Lobby)
                    game.Message = $"{game.Players[0].Name} is now the host.";
            }

            if (game.Phase == GamePhase.Playing)
            {
                if (removedIndex < game.CurrentPlayerIndex)
                    game.CurrentPlayerIndex--;

                if (wasCurrentPlayer)
                    AdvanceIfNeeded(game);
            }

            if (game.Phase == GamePhase.Betting && game.Players.All(p => p.CurrentBet > 0))
                DealInitialCards(game);

            return true;
        }
    }


    public bool TrySpectate(string gameId, string connectionId, out string error)
    {
        lock (_sync)
        {
            error = "";
            var game = GetGameUnsafe(gameId);
            if (game == null || game.Mode != GameMode.Multiplayer)
            {
                error = "Spectating is available only in multiplayer tables.";
                return false;
            }
            if (game.Spectators.Any(s => s.ConnectionId == connectionId)) return true;
            var player = game.Players.FirstOrDefault(p => p.ConnectionId == connectionId);
            if (player == null || game.Phase != GamePhase.RoundOver || player.Chips >= MinimumBet)
            {
                error = "You can spectate only after a round when you have fewer than 10 chips.";
                return false;
            }
            var remaining = game.Players.Where(p => p.ConnectionId != connectionId && p.Chips >= MinimumBet).ToList();
            if (remaining.Count == 0)
            {
                error = "No funded players remain. Return to game selection.";
                return false;
            }
            game.Players.Remove(player);
            game.Spectators.Add(new Spectator { ConnectionId = connectionId, Name = player.Name });
            if (game.HostConnectionId == connectionId)
                game.HostConnectionId = remaining[0].ConnectionId;
            return true;
        }
    }

    public bool TrySendChat(string gameId, string connectionId, string? message, out string error)
    {
        lock (_sync)
        {
            error = "";
            var game = GetGameUnsafe(gameId);
            if (game == null || game.Mode != GameMode.Multiplayer)
            {
                error = "Chat is available only in multiplayer games.";
                return false;
            }
            var player = game.Players.FirstOrDefault(p => p.ConnectionId == connectionId);
            var spectator = game.Spectators.FirstOrDefault(s => s.ConnectionId == connectionId);
            if (player == null && spectator == null)
            {
                error = "Join this game before sending a message.";
                return false;
            }
            var text = message?.Trim() ?? "";
            if (text.Length == 0 || text.Length > MaxChatLength || text.Any(char.IsControl))
            {
                error = "Enter a message between 1 and 200 characters with no control characters.";
                return false;
            }
            // Store a color per participant rather than per display name, since names can repeat.
            if (!game.ChatSenderColors.TryGetValue(connectionId, out var colorIndex))
            {
                colorIndex = game.ChatSenderColors.Count % ChatColorCount;
                game.ChatSenderColors[connectionId] = colorIndex;
            }
            game.ChatMessages.Add(new ChatMessage
            {
                Sender = player?.Name ?? spectator!.Name,
                Text = text,
                ColorIndex = colorIndex
            });
            if (game.ChatMessages.Count > MaxChatHistory)
                game.ChatMessages.RemoveRange(0, game.ChatMessages.Count - MaxChatHistory);
            return true;
        }
    }

    public bool StartBetting(string gameId, string connectionId, out string error)
    {
        lock (_sync)
        {
            error = "";
            if (!_games.TryGetValue(gameId, out var game))
                error = "Game not found.";
            else if (game.HostConnectionId != connectionId)
                error = "Only the host can start the game.";
            else if (game.Phase != GamePhase.Lobby)
                error = "This game has already started.";
            else if (game.Players.Count < 1)
                error = "At least one player is required to start.";
            else if (game.Mode == GameMode.Multiplayer && game.Players.Count < 2 && game.Spectators.Count == 0)
                error = "At least two players are required for multiplayer. Share your lobby code with a friend.";

            if (!string.IsNullOrEmpty(error)) return false;

            game!.Phase = GamePhase.Betting;
            game.Message = "Place your bets!";
            foreach (var p in game.Players)
            {
                p.CurrentBet = 0;
                p.Hand.Clear();
                p.Status = PlayerStatus.Waiting;
            }
            game.Dealer.Hand.Clear();
            return true;
        }
    }

    public bool PlaceBet(string gameId, string connectionId, int amount, out string error)
    {
        lock (_sync)
        {
            var game = GetGameUnsafe(gameId);
            var player = game?.Players.FirstOrDefault(p => p.ConnectionId == connectionId);
            if (player == null)
            {
                error = "You are not a player in this game.";
                return false;
            }

            if (game!.Phase != GamePhase.Betting)
            {
                error = "Betting is not open right now.";
                return false;
            }

            if (player.CurrentBet > 0)
            {
                error = "You have already placed a bet for this round.";
                return false;
            }

            if (amount < MinimumBet)
            {
                error = $"The minimum bet is {MinimumBet} chips.";
                return false;
            }

            if (amount > player.Chips)
            {
                error = "Your bet cannot be greater than your available balance.";
                return false;
            }

            player.CurrentBet = amount;

            if (game.AllBetsPlaced)
                DealInitialCards(game);

            error = "";
            return true;
        }
    }

    public bool Hit(string gameId, string connectionId)
    {
        lock (_sync)
        {
            var game = GetGameUnsafe(gameId);
            var player = game?.CurrentPlayer;
            if (player == null || player.ConnectionId != connectionId || player.Status != PlayerStatus.Playing) return false;

            player.Hand.Add(_decks[gameId].Deal());
            if (player.IsBusted)
            {
                player.Status = PlayerStatus.Busted;
                AdvancePlayer(game!);
            }
            else if (player.HandValue == 21)
            {
                player.Status = PlayerStatus.Standing;
                AdvancePlayer(game!);
            }
            return true;
        }
    }

    public bool Stand(string gameId, string connectionId)
    {
        lock (_sync)
        {
            var game = GetGameUnsafe(gameId);
            var player = game?.CurrentPlayer;
            if (player == null || player.ConnectionId != connectionId || player.Status != PlayerStatus.Playing) return false;

            player.Status = PlayerStatus.Standing;
            AdvancePlayer(game!);
            return true;
        }
    }

    public bool ResetRound(string gameId, string? requestingConnectionId = null)
    {
        lock (_sync)
        {
            var game = GetGameUnsafe(gameId);
            if (game == null || game.Phase != GamePhase.RoundOver) return false;
            if (requestingConnectionId != null && !game.Players.Any(p => p.ConnectionId == requestingConnectionId))
                return false;

            var eliminated = game.Players.Where(p => p.Chips < MinimumBet).ToList();
            foreach (var player in eliminated)
            {
                game.Players.Remove(player);
                if (game.Mode == GameMode.Multiplayer)
                    game.Spectators.Add(new Spectator { ConnectionId = player.ConnectionId, Name = player.Name });
                else
                    _connectionIndex.Remove(player.ConnectionId);
            }

            if (game.Players.Count == 0)
            {
                foreach (var spectator in game.Spectators)
                    _connectionIndex.Remove(spectator.ConnectionId);
                _games.Remove(gameId);
                _decks.Remove(gameId);
                return true;
            }

            if (!game.Players.Any(p => p.ConnectionId == game.HostConnectionId))
                game.HostConnectionId = game.Players[0].ConnectionId;

            game.Phase = GamePhase.Lobby;
            game.Message = "Waiting for players...";
            return true;
        }
    }

    private GameState? GetGameUnsafe(string gameId) =>
        _games.TryGetValue(gameId, out var game) ? game : null;

    private static PlayerDto MapPlayer(Player player, bool hideHoleCard = false) => new()
    {
        ConnectionId = player.ConnectionId,
        Name = player.Name,
        Avatar = player.Avatar,
        Chips = player.Chips,
        CurrentBet = player.CurrentBet,
        HandValue = hideHoleCard ? 0 : player.HandValue,
        Status = player.Status.ToString(),
        Hand = player.Hand.Select((card, index) =>
        {
            var isHidden = hideHoleCard && index == 1;
            return new CardDto
            {
                Display = isHidden ? "" : card.Display,
                IsRed = !isHidden && card.IsRed,
                IsHidden = isHidden
            };
        }).ToList()
    };

    private void DealInitialCards(GameState game)
    {
        var deck = _decks[game.GameId];
        deck.Reset();
        foreach (var p in game.Players) { p.Hand.Add(deck.Deal()); p.Hand.Add(deck.Deal()); }
        game.Dealer.Hand.Add(deck.Deal());
        game.Dealer.Hand.Add(deck.Deal());

        game.Phase = GamePhase.Playing;
        game.CurrentPlayerIndex = 0;
        game.Message = $"{game.Players[0].Name}'s turn";

        foreach (var p in game.Players)
            p.Status = p.HasBlackjack ? PlayerStatus.Blackjack : PlayerStatus.Playing;

        AdvanceIfNeeded(game);
    }

    private void AdvanceIfNeeded(GameState game)
    {
        while (game.CurrentPlayerIndex < game.Players.Count &&
               game.Players[game.CurrentPlayerIndex].Status != PlayerStatus.Playing)
        {
            game.CurrentPlayerIndex++;
        }

        if (game.CurrentPlayerIndex >= game.Players.Count)
            DealerTurn(game);
        else
            game.Message = $"{game.Players[game.CurrentPlayerIndex].Name}'s turn";
    }

    private void AdvancePlayer(GameState game)
    {
        game.CurrentPlayerIndex++;
        AdvanceIfNeeded(game);
    }

    private void DealerTurn(GameState game)
    {
        game.Phase = GamePhase.DealerTurn;
        var deck = _decks[game.GameId];

        while (game.Dealer.HandValue < 17)
            game.Dealer.Hand.Add(deck.Deal());

        SettleRound(game);
    }

    private void SettleRound(GameState game)
    {
        int dealerValue = game.Dealer.HandValue;
        bool dealerBusted = game.Dealer.IsBusted;
        bool dealerBlackjack = game.Dealer.HasBlackjack;

        foreach (var p in game.Players)
        {
            if (p.IsBusted || (dealerBlackjack && !p.HasBlackjack))
            {
                p.Chips -= p.CurrentBet;
                p.Status = PlayerStatus.Lost;
                continue;
            }

            if (p.HasBlackjack && !dealerBlackjack)
            {
                p.Chips += p.CurrentBet * 1.5m;
                p.Status = PlayerStatus.Won;
                continue;
            }

            int pv = p.HandValue;
            if (dealerBusted || pv > dealerValue) { p.Chips += p.CurrentBet; p.Status = PlayerStatus.Won; }
            else if (pv < dealerValue) { p.Chips -= p.CurrentBet; p.Status = PlayerStatus.Lost; }
            else { p.Status = PlayerStatus.Push; }
        }

        game.Phase = GamePhase.RoundOver;
        game.Message = "Round over! Ready for next round?";
    }

}
