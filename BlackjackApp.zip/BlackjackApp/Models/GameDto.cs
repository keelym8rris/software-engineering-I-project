namespace BlackjackApp.Models;

// Flat DTOs for safe serialization over the wire — no computed properties, no null surprises
public class CardDto
{
    public string Display { get; set; } = "";
    public bool IsRed { get; set; }
    public bool IsHidden { get; set; }
}

public class PlayerDto
{
    public string ConnectionId { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Avatar { get; set; }
    public List<CardDto> Hand { get; set; } = new();
    public string Status { get; set; } = "Waiting";
    public decimal Chips { get; set; }
    public int CurrentBet { get; set; }
    public int HandValue { get; set; }
}

public class SpectatorDto
{
    public string ConnectionId { get; set; } = "";
    public string Name { get; set; } = "";
}

public class ChatMessageDto
{
    public string Sender { get; set; } = "";
    public string Text { get; set; } = "";
    public int ColorIndex { get; set; }
}

public class GameStateDto
{
    public string GameId { get; set; } = "";
    public string HostConnectionId { get; set; } = "";
    public string Mode { get; set; } = "Multiplayer";
    public string Phase { get; set; } = "Lobby";
    public string Message { get; set; } = "";
    public List<PlayerDto> Players { get; set; } = new();
    public List<SpectatorDto> Spectators { get; set; } = new();
    public List<ChatMessageDto> ChatMessages { get; set; } = new();
    public PlayerDto Dealer { get; set; } = new();
    public string? CurrentPlayerConnectionId { get; set; }
}
